package br.com.fiap.teste;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.Test;

import br.com.fiap.dao.impl.CasoTesteDAOImpl;
import br.com.fiap.dao1.CasoTesteDAO;
import br.com.fiap.entity.CasoTeste;
import br.com.fiap.entity.ItemTeste;
import br.com.fiap.entity.Sistema;
import br.com.fiap.entity.Usuario;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class Teste {

	@Test
	public void test() {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		CasoTesteDAO dao = new CasoTesteDAOImpl(em);
		
		Sistema sistema = new Sistema();
		sistema.setNome("Controle temperatura");
		
		CasoTeste caso = new CasoTeste();
		caso.setNome("Função de aumentar a temperatura");
		
		ItemTeste item1 = new ItemTeste();
		item1.setDescricao("Aumentar a temperatura após o clique do botão");
		
		ItemTeste item2 = new ItemTeste();
		item2.setDescricao("Aumentar a temperatura até o limite");
		
		Usuario usuario = new Usuario();
		usuario.setNome("Fernando Leonardo");
		
		caso.setSistema(sistema);
		caso.addItem(item1);
		caso.addItem(item2);
		
		List<Usuario> usuarios = new ArrayList<>();
		usuarios.add(usuario);
		
		item1.setUsuarios(usuarios);
		item2.setUsuarios(usuarios);
		
		try {
			dao.cadastrar(caso);
			dao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
			fail();
		}
		
	}

}
