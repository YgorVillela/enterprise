package br.com.fiap.dao1;

public interface ItemTesteDAO {

}
