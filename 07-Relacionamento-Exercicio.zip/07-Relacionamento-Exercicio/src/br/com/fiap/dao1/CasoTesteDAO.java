package br.com.fiap.dao1;

import br.com.fiap.entity.CasoTeste;

public interface CasoTesteDAO extends GenericDAO<CasoTeste, Integer>{

}
