package br.com.fiap.dao.impl;

public class SistemaDAOImpl {

}
